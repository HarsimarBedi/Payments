package payments;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Billing {

	private static final String COMMA_DELIMITER = ", ";

	private static StopsAndCharges stopsAndCharges1To2 = new StopsAndCharges("Stop1", "Stop2", 3.25);
	private static StopsAndCharges stopsAndCharges2To3 = new StopsAndCharges("Stop2", "Stop3", 5.50);
	private static StopsAndCharges stopsAndCharges1To3 = new StopsAndCharges("Stop1", "Stop3", 7.30);
	private static String filePath = new File("").getAbsolutePath();

	public static void main(String[] args) {
		List<StopsAndCharges> stopsAndChargesList = new ArrayList<StopsAndCharges>();
		stopsAndChargesList.add(stopsAndCharges1To2);
		stopsAndChargesList.add(stopsAndCharges2To3);
		stopsAndChargesList.add(stopsAndCharges1To3);
		// List of taps
		List<TapDetails> tapDetailsList = getTapDetailsList();

		// Incomplete trip
		if (tapDetailsList.size() == 1) {
			calculateIncompleteTrip(tapDetailsList, stopsAndChargesList);
		// Complete trip
		} else if (tapDetailsList.size() == 2) {
			calculateCompleteTrip(tapDetailsList, stopsAndChargesList);
		// Invalid file
		} else {
			StringBuffer oneLine = new StringBuffer();
			oneLine.append("Invalid taps file");
			invoiceWriter(oneLine);
		}
	}

	private static List<TapDetails> getTapDetailsList() {
		BufferedReader br = null;
		List<TapDetails> tapDetailsList = new ArrayList<TapDetails>();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss", Locale.getDefault());
		try {
			// Reading the csv file
			br = new BufferedReader(new FileReader(filePath + "/src/payments/taps.csv"));

			String line = "";
			br.readLine();
			while ((line = br.readLine()) != null) {
				String[] tapDetails = line.split(COMMA_DELIMITER);

				if (tapDetails.length > 0) {
					// Save the tap details in TapDetails object
					TapDetails details = new TapDetails(Integer.parseInt(tapDetails[0].trim()),
							LocalDateTime.parse(tapDetails[1].trim(), formatter), tapDetails[2].trim(),
							tapDetails[3].trim(), tapDetails[4].trim(), tapDetails[5].trim(),
							Long.parseLong(tapDetails[6].trim()));
					tapDetailsList.add(details);
				}
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		}
		return tapDetailsList;
	}

	private static void calculateIncompleteTrip(List<TapDetails> tapDetailsList,
			List<StopsAndCharges> stopsAndChargesList) {
		String stopId = tapDetailsList.get(0).getStopID();
		double maxCharge = 0;

		for (StopsAndCharges stopCharge : stopsAndChargesList) {
			if (stopCharge.getPointA().equals(stopId) || stopCharge.getPointB().equals(stopId)) {
				if (stopCharge.getCharges() > maxCharge)
					maxCharge = stopCharge.getCharges();
			}
		}
		printInvoice(new TripInvoice(tapDetailsList.get(0).getDateTimeUTC().toString(), "N/A", 0l,
				tapDetailsList.get(0).getStopID(), "N/A", String.valueOf(maxCharge),
				tapDetailsList.get(0).getCompanyID(), tapDetailsList.get(0).getBusID(), tapDetailsList.get(0).getPan(),
				"COMPLETED"));
	}

	private static void calculateCompleteTrip(List<TapDetails> tapDetailsList,
			List<StopsAndCharges> stopsAndChargesList) {
		String stopId1 = tapDetailsList.get(0).getStopID();
		String stopId2 = tapDetailsList.get(1).getStopID();
		Duration duration = Duration.between(tapDetailsList.get(0).getDateTimeUTC(),
				tapDetailsList.get(1).getDateTimeUTC());
		if (stopId1.equals(stopId2)) {
			// Cancelled trip
			printInvoice(new TripInvoice(tapDetailsList.get(0).getDateTimeUTC().toString(),
					tapDetailsList.get(1).getDateTimeUTC().toString(), duration.toSeconds(),
					tapDetailsList.get(0).getStopID(), tapDetailsList.get(1).getStopID(), "N/A",
					tapDetailsList.get(0).getCompanyID(), tapDetailsList.get(0).getBusID(),
					tapDetailsList.get(0).getPan(), "CANCELLED"));
		} else {
			for (StopsAndCharges stopCharge : stopsAndChargesList) {
				if ((stopCharge.getPointA().equals(stopId1) || stopCharge.getPointB().equals(stopId1))
						&& (stopCharge.getPointA().equals(stopId2) || stopCharge.getPointB().equals(stopId2))) {
					printInvoice(new TripInvoice(tapDetailsList.get(0).getDateTimeUTC().toString(),
							tapDetailsList.get(1).getDateTimeUTC().toString(), duration.toSeconds(),
							tapDetailsList.get(0).getStopID(), tapDetailsList.get(1).getStopID(),
							String.valueOf(stopCharge.getCharges()), tapDetailsList.get(0).getCompanyID(),
							tapDetailsList.get(0).getBusID(), tapDetailsList.get(0).getPan(), "COMPLETED"));
				}
			}
		}
	}

	private static void printInvoice(TripInvoice tripInvoice) {
		StringBuffer oneLine = new StringBuffer();
		// Headings
		oneLine.append("Started").append(COMMA_DELIMITER).append("Finished").append(COMMA_DELIMITER)
				.append("DurationSecs").append(COMMA_DELIMITER).append("FromStopId").append(COMMA_DELIMITER)
				.append("ToStopId").append(COMMA_DELIMITER).append("ChargeAmount").append(COMMA_DELIMITER)
				.append("CompanyId").append(COMMA_DELIMITER).append("BusId").append(COMMA_DELIMITER).append("PAN")
				.append(COMMA_DELIMITER).append("Status");
		// Line Break
		oneLine.append("\n");
		// Data Entry
		oneLine.append(tripInvoice.getStarted()).append(COMMA_DELIMITER).append(tripInvoice.getFinished())
				.append(COMMA_DELIMITER).append(tripInvoice.getDurationSecs()).append(COMMA_DELIMITER)
				.append(tripInvoice.getFromStopId()).append(COMMA_DELIMITER).append(tripInvoice.getToStopId())
				.append(COMMA_DELIMITER).append(tripInvoice.getChargeAmount()).append(COMMA_DELIMITER)
				.append(tripInvoice.getCompanyId()).append(COMMA_DELIMITER).append(tripInvoice.getBusID())
				.append(COMMA_DELIMITER).append(tripInvoice.getPan()).append(COMMA_DELIMITER)
				.append(tripInvoice.getStatus());
		invoiceWriter(oneLine);
	}

	private static void invoiceWriter(StringBuffer oneLine) {

		try {
			BufferedWriter bw = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(filePath + "/src/payments/trips.csv"), "UTF-8"));
			bw.write(oneLine.toString());
			bw.newLine();
			bw.flush();
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
