package payments;

public class StopsAndCharges {
	private String pointA;
	private String pointB;
	private double charges;
	
	public StopsAndCharges(String pointA,String pointB, double d) {
		this.pointA = pointA;
		this.pointB = pointB;
		this.charges = d;
	}

	public String getPointA() {
		return pointA;
	}

	public void setPointA(String pointA) {
		this.pointA = pointA;
	}

	public String getPointB() {
		return pointB;
	}

	public void setPointB(String pointB) {
		this.pointB = pointB;
	}

	public double getCharges() {
		return charges;
	}

	public void setCharges(double charges) {
		this.charges = charges;
	}

	
}
