package payments;

import java.time.LocalDateTime;

public class TapDetails {
	  private int id;
	  private LocalDateTime dateTimeUTC;
	  private String tapType;
	  private String stopID;
	  private String companyID;
	  private String busID;
	  private long pan;
	  
	
	public TapDetails() {
		// TODO Auto-generated constructor stub
	}


	public TapDetails(int id, LocalDateTime dateTimeUTC, String tapType, String stopID, String companyID, String busID,
			long pan) {
		this.id = id;
		this.dateTimeUTC = dateTimeUTC;
		this.tapType = tapType;
		this.stopID = stopID;
		this.companyID = companyID;
		this.busID = busID;
		this.pan = pan;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public LocalDateTime getDateTimeUTC() {
		return dateTimeUTC;
	}


	public void setDateTimeUTC(LocalDateTime dateTimeUTC) {
		this.dateTimeUTC = dateTimeUTC;
	}


	public String getTapType() {
		return tapType;
	}


	public void setTapType(String tapType) {
		this.tapType = tapType;
	}


	public String getStopID() {
		return stopID;
	}


	public void setStopID(String stopID) {
		this.stopID = stopID;
	}


	public String getCompanyID() {
		return companyID;
	}


	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}


	public String getBusID() {
		return busID;
	}


	public void setBusID(String busID) {
		this.busID = busID;
	}


	public long getPan() {
		return pan;
	}


	public void setPan(long pan) {
		this.pan = pan;
	}

}