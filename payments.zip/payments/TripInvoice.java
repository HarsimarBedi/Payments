package payments;

public class TripInvoice {
	
	public String started;
	public String finished;
	public long durationSecs;
	public String fromStopId;
	public String toStopId;
	public String chargeAmount;
	public String companyId;
	public String busID;
	public long pan;
	public String status;
	public TripInvoice(String started, String finished, long durationSecs, String fromStopId, String toStopId,
			String chargeAmount, String companyId, String busID, long pan, String status) {
		this.started = started;
		this.finished = finished;
		this.durationSecs = durationSecs;
		this.fromStopId = fromStopId;
		this.toStopId = toStopId;
		this.chargeAmount = chargeAmount;
		this.companyId = companyId;
		this.busID = busID;
		this.pan = pan;
		this.status = status;
	}
	public String getStarted() {
		return started;
	}
	public void setStarted(String started) {
		this.started = started;
	}
	public String getFinished() {
		return finished;
	}
	public void setFinished(String finished) {
		this.finished = finished;
	}
	public long getDurationSecs() {
		return durationSecs;
	}
	public void setDurationSecs(long durationSecs) {
		this.durationSecs = durationSecs;
	}
	public String getFromStopId() {
		return fromStopId;
	}
	public void setFromStopId(String fromStopId) {
		this.fromStopId = fromStopId;
	}
	public String getToStopId() {
		return toStopId;
	}
	public void setToStopId(String toStopId) {
		this.toStopId = toStopId;
	}
	public String getChargeAmount() {
		return chargeAmount;
	}
	public void setChargeAmount(String chargeAmount) {
		this.chargeAmount = chargeAmount;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getBusID() {
		return busID;
	}
	public void setBusID(String busID) {
		this.busID = busID;
	}
	public long getPan() {
		return pan;
	}
	public void setPan(long pan) {
		this.pan = pan;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}